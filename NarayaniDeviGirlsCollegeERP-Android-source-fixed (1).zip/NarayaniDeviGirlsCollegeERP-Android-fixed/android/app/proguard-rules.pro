# Narayani Devi Girls College ERP release rules
# Retrofit/Gson models use annotations; keep model field names for JSON parsing.
-keepattributes *Annotation*
-keep class in.ndedu.erp.data.models.** { *; }
-dontwarn javax.annotation.**
